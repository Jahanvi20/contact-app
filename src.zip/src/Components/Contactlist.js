import React, {useRef}  from "react";
import {Link} from 'react-router-dom';
import Contactcard from "./Contactcard";

const Contactlist = (props) => {
    // console.log(props);
    const inputEl = useRef("");

    const deleteContactHandler = (id) => {
        props.getContactId(id);
    };

    const renderContactlist = props.contacts.map((contact) => {
        return (
            <Contactcard contact={contact} 
            clickHandler = {deleteContactHandler} 
            key = {contact.id} 
            />
        );
    });

    const getSearchTerm = () => {
        props.searchKeyword(inputEl.current.value);
    };
    return (
        <div class="main">
            <h2>
                Contact list
                <Link to="/add">
                <button className="ui button blue right">Add Contact</button>
                </Link>
            </h2>
            <div className="ui search">
                <div className="ui icon input">
                    <input 
                    ref={inputEl}
                    type="text" 
                    placeholder="Search Contacts" 
                    className="prompt" 
                    value={props.term} 
                    onChange={getSearchTerm}
                    />
                    <i className="search icon"></i>
                </div>
            </div>
        <div className="ui called list">
        {renderContactlist.length > 0
          ? renderContactlist
          : "No Contacts Available"}
        </div>
      </div>
    );
};

export default Contactlist;